package JDK;

import org.junit.Test;

/**
 * Created by Administrator on 2016/11/3 0003.
 */
public class IntegerTest {

    @Test
    public void testInt(){
        System.out.println(1<<2);
    }
}
