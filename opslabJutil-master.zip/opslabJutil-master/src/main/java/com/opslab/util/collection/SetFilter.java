package com.opslab.util.collection;

/**
 * <h6>Description:Set过滤接口<h6>
 * <p></p>
 *
 * @date 2015-07-23.
 */
public interface SetFilter<T> {
    public boolean filter(T t);
}
