package com.opslab.util.collection;

/**
 * <h6>Description:Map过滤接口<h6>
 * <p></p>
 *
 * @date 2015-07-23.
 */
public interface MapFilter<T> {
    public boolean filter(T t);
}
