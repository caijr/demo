package com.opslab.util.bean;

/**
 * 属性过滤接口
 */
public interface PropertyFilter {
    public String Properties(String pro);
}
